console.log('Loading function');

var AWS = require('aws-sdk');
var dynamo = new AWS.DynamoDB.DocumentClient();
var table = "controleContinuoDynamo-dev";
var config = {};
config.IOT_BROKER_ENDPOINT = "a1u5p9d1s2ikgy-ats.iot.us-east-1.amazonaws.com";
config.IOT_BROKER_REGION = "us-east-1";
config.IOT_THING_NAME = "dispositivoControle";

AWS.config.region = config.IOT_BROKER_REGION;

exports.handler = function(event, context) { 

    console.log(event.id, event.modeOp)    
    var params = {
                TableName:table,
                Key:{
                    "id": event.id,
                },
                UpdateExpression: "set modeOp = :val1",
                ExpressionAttributeValues:{
                    ":val1": event.modeOp
                },
                ReturnValues:"UPDATED\_NEW"
            };
            dynamo.update(params, function(err, data) {
                if (err) {
                    console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                    context.fail();
                } else {
                    console.log("Tabela atualizada!", JSON.stringify(data, null, 2));
                    context.succeed("Tabela atualizada");
                }
            });
};

