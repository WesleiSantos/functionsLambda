const Alexa = require('ask-sdk-core');
let AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
//const docClient = new AWS.DynamoDB.DocumentClient({region: 'eu-west-1'});

var config = {};
config.IOT_BROKER_ENDPOINT = "a1u5p9d1s2ikgy-ats.iot.us-east-1.amazonaws.com";
config.IOT_BROKER_REGION = "us-east-1";
config.IOT_THING_NAME = "dispositivoControle";

AWS.config.region = config.IOT_BROKER_REGION;
const iot = new AWS.IotData({"endpoint":config.IOT_BROKER_ENDPOINT});

const log = function(title, msg) {
  console.log('**** ' + title + ': ' + JSON.stringify(msg));
}// log

var postMQTT = function(topic, msg) {
  var params =  {
    "topic" : topic,
    "payload" : msg,
    "qos" : "0"
  };
  iot.publish(params, function(err, data) {
    if (err) { 
        log("Error", "MQTT FAIL");
        log(err, err.stack);
    } else { 
        log("MQTT Success", data);
    }
  });
}

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Olá, você pode dizer status do dispositivo, ativar modo alarme, ativar modo detecção de acidente, tempo de conexão ou alterar tempo de conexão.';
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const sayConnectionTimeHandler = {
    //... Your canHandle function for intent ...
     canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'sayConnectionTime';
    },
    async handle(handlerInput) {
        
        var params = {
                KeyConditionExpression: "id =:id",
                ExpressionAttributeValues: {
                ":id": Number(1)
            },
            TableName: "controleContinuoDynamo-dev"
        }
        
        const tableData = await docClient.query(params, (err, data) => {
            if (err) {
                console.log('Scan FAILED', err);
                throw new Error('Error while scanning table');
            }
            return data;
        }).promise();
            console.log("veio AQUI");
           console.log("tableData=",tableData.Items[0]);
           let items = tableData.Items[0];
           const {id:id, connectionTime:connectionTime, modoOp:modoOp, status_connection:status_connection} = items;
           console.log("valores",id,connectionTime,modoOp,status_connection);
           let speechText = "";
           if(connectionTime==1){
              speechText = "Tempo de conexão atual é: "+ connectionTime + " minuto";
           }else{
              speechText = "Tempo de conexão atual é: "+ connectionTime + " minutos";
           }
           

          
        // ... Use table data as required ...
         return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse()
    }
};

const getStatusDeviceHandler = {
    //... Your canHandle function for intent ...
     canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'getStatusDevice';
    },
    async handle(handlerInput) {
        
        var params = {
                KeyConditionExpression: "id =:id",
                ExpressionAttributeValues: {
                ":id": Number(1)
            },
            TableName: "controleContinuoDynamo-dev"
        }
        
        const tableData = await docClient.query(params, (err, data) => {
            if (err) {
                console.log('Scan FAILED', err);
                throw new Error('Error while scanning table');
            }
            return data;
        }).promise();
            console.log("veio AQUI");
           console.log("tableData=",tableData.Items[0]);
           let items = tableData.Items[0];
           const {id:id, connectionTime:connectionTime, modoOp:modoOp, status_connection:status_connection} = items;
           console.log("valores",id,connectionTime,modoOp,status_connection);
           let speechText = "";
           if(status_connection == 0){
             speechText = "O dispositivo está desconectado";  
           }else{
             speechText = "O dispositivo está conectado";
           } 
            

          
        // ... Use table data as required ...
         return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse()
    }
};

const activateAlarmHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'activateAlarm';
    },
    handle(handlerInput) {
        const {requestEnvelope, responseBuilder} = handlerInput;
        const {intent} = requestEnvelope.request;
        console.log("intent ",intent);
        
        const speechText = "modo alarme ativado";
        
        postMQTT("esp8266/mode",`{"modeOp":${1}}`);
        
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const enableMonitoringHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'enableMonitoring';
    },
    handle(handlerInput) {
        const {requestEnvelope, responseBuilder} = handlerInput;
        const {intent} = requestEnvelope.request;
        console.log("intent ",intent);
        
        const speechText = "modo monitoramento ativado";
        
        postMQTT("esp8266/mode", `{"modeOp":${0}}`);
        
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const ChangeTimeIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'changeTime';
    },
    handle(handlerInput) {
        const {requestEnvelope, responseBuilder} = handlerInput;
        const {intent} = requestEnvelope.request;
        const timeSlot = intent.slots.time.value;
        console.log("intent ",{intent});
        console.log("timeSlot ", timeSlot)
        
        postMQTT("esp8266/Timer",`{"connectionTime":${timeSlot}}`);
        const speechText = "Tempo alterado para " + timeSlot + "minutos";
        
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};

const HelloWorldIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'HelloWorldIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Hello World!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest' &&
            (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent' ||
                handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = handlerInput.requestEnvelope.request.intent.name;
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Desculpe, tive problemas para fazer o que você pediu. Por favor, tente novamente.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        ChangeTimeIntentHandler,
        sayConnectionTimeHandler,
        activateAlarmHandler,
        enableMonitoringHandler,
        getStatusDeviceHandler,
        HelloWorldIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .lambda();